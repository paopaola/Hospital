# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import base64
import logging

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError
from odoo.modules.module import get_module_resource
from datetime import timedelta, datetime

# Krijimi i tabeles Pacienti

class Pacienti(models.Model):

    _name = "spital.pacienti"
    _description = "Pacienti"
    _order = "name"

    nr_personal = fields.Char(string="Nr. personal", required=True)
    name = fields.Char(string="Emri", required=True)
    # emri = fields.Char(string="Emri", required=True)
    # mbiemri = fields.Char(string="Mbiemri", required=True)
    # emri_mbiemri = fields.Char(string="Emri Plotë", compute='_emri_plote')
    amesia = fields.Char(string="Amësia", required=True)
    atesia = fields.Char(string="Atësia", required=True)
    ditelindja = fields.Date(string="Ditëlindja", required=True)
    gjinia = fields.Selection([
        #('zgjidh', "Zgjidh"),
        ('mashkull', 'Mashkull'),
        ('femer', 'Femër')
    ], string="Gjinia", required=True) #, default="zgjidh")
    gjendja_civile = fields.Selection([
        #('zgjidh', "Zgjidh"),
        ('beqar', 'Beqar/e'),
        ('martuar', 'I/E martuar'),
        ('divorcuar', 'I/E divorcuar'),
        ('ve', 'I/E ve')
    ], string="Gjendja Civile") #, default="zgjidh")
    grupi_gjakut = fields.Selection(
        [('0+', '0+'), ('0-', '0-'), ('a+', 'A+'), ('a-', 'A-'), ('b+', 'B+'), ('b-', 'B-'), ('ab+', 'AB+'), ('ab-', 'AB-')],
        string="Grupi i gjakut")
    vendlindja = fields.Char(string="Vendlindja")
    adresa = fields.Text(string="Adresa")
    cel = fields.Char(string="Nr. kontakti")
    email = fields.Char(string="E-mail")

    # @api.depends('emri', 'mbiemri')
    # def _emri_plote(self):
    #     for record in self:
    #         emri_mbiemri = ''
    #         if record.emri:
    #             emri_mbiemri = record.emri
    #             if record.mbiemri:
    #                 emri_mbiemri += record.mbiemri
    #         record.emri_mbiemri = emri_mbiemri


    # Kufizon qe detyron nr. personal te jete unik
    _sql_constraints = [
        ('nr_personal_unik', 'unique (nr_personal)',
         "Numri personal është unik për çdo individ!"),
    ]

    # @api.constrains('nr_personal')
    # def _nr_personal_unik(self):
    #     for record in self:
    #         if self.count(record)>= 2:
    #             raise ValidationError("Numri personal është unik për çdo individ!")

   # Kufizim qe kontrollon nese nr personal ka 10 char.
    @api.constrains('nr_personal')
    def _nr_personal_length(self):
        if (len(self.nr_personal) != 10):
            raise ValidationError("Numri personal duhet te jete me 10 karaktere!")


# Krijimi i tabeles Doktori
class Doktori(models.Model):

    _name = "spital.doktori"
    _description = "Doktori"
    _order = "name"

    @api.model
    def _default_image(self):
        image_path = get_module_resource('spitali', 'static/src/img', 'default_image.png')
        return tools.image_resize_image_big(base64.b64encode(open(image_path, 'rb').read()))

    #Info rreth punes
    departamenti = fields.Many2one('spital.departamenti', 'Departamenti')
    zyra = fields.Char(string="Zyra")
    cel_pune = fields.Char(string="Nr. kontakti")
    email_pune = fields.Char(string="E-mail")
    specializim = fields.One2many('spital.specializimi', 'mjek_id', string="Specializimet")
    #specializimi_fundit = fields.Many2one(compute='', 'spital.specializimi', string="Specializimi")
    statusi_dok = fields.Selection([
        ('disponueshem', 'I disponueshëm'),
        ('padisponueshem', 'I padisponueshëm'),
        ('zene', 'I zënë')
    ], string="Statusi i Doktorit", default="disponueshem")


    #Info personal
    nr_personal = fields.Char(string="Nr. personal", required=True)
    name = fields.Char(string="Emri", required=True)
    # emri = fields.Char(string="Emri", required=True)
    # mbiemri = fields.Char(string="Mbiemri", required=True)
    atesia = fields.Char(string="Atësia", required=True)
    gjinia = fields.Selection([
        ('mashkull', 'Mashkull'),
        ('femer', 'Femër')
    ], string="Gjinia", required=True)
    gjendja_civile = fields.Selection([
        ('beqar', 'Beqar/e'),
        ('martuar', 'I/E martuar'),
        ('divorcuar', 'I/E divorcuar'),
        ('ve', 'I/E ve')
    ], string="Gjendja Civile")
    ditelindja = fields.Date('Ditelindja')
    grupi_gjakut = fields.Selection(
        [('0+', '0+'), ('0-', '0-'), ('a+', 'A+'), ('a-', 'A-'), ('b+', 'B+'), ('b-', 'B-'), ('ab+', 'AB+'),
         ('ab-', 'AB-')],
        string="Grupi i gjakut")
    vendlindja = fields.Char(string="Vendlindja")
    adresa = fields.Text(string="Adresa")
    cel_personal = fields.Char(string="Nr. kontakti personal")
    email_personal = fields.Char(string="E-mail personal")

    foto = fields.Binary(
        "Foto", default='_default_image', attachment=True,
        help="This field holds the image used as photo for the doctor, limited to 1024x1024px.")
    foto_mesatare = fields.Binary(
        "Foto me madhesi mesatare", default='_default_image', attachment=True,
        help="Medium-sized photo of the doctor. It is automatically "
             "resized as a 128x128px image, with aspect ratio preserved. "
             "Use this field in form views or some kanban views.")
    foto_vogel = fields.Binary(
        "Foto me madhesi te vogel", default='_default_image', attachment=True,
        help="Small-sized photo of the doctor. It is automatically "
             "resized as a 64x64px image, with aspect ratio preserved. "
             "Use this field anywhere a small image is required.")

    @api.model
    def create(self, vals):
        tools.image_resize_images(vals)
        return super(Doktori, self).create(vals)

    # @api.model
    # def create(self, vals):
    #     if vals.get('user_id'):
    #         vals.update(self._sync_user(self.env['res.users'].browse(vals['user_id'])))
    #     tools.image_resize_images(vals)
    #     return super(Employee, self).create(vals)

        # Kufizon qe detyron nr. personal te jete unik
        _sql_constraints = [
            ('nr_personal_unik_dok', 'unique (nr_personal)',
             "Numri personal është unik për çdo individ!"),
        ]

        # Kufizim qe kontrollon nese nr personal ka 10 char.
        # @api.constrains('nr_personal')
        # def _nr_personal_length_dok(self):
        #     for record in self:
        #         if len(record) != 10:
        #             raise ValidationError("Numri personal duhet te jete me 10 karaktere!")


# Krijimi i tabeles Specializimi

class Specializimi (models.Model):
    _name = "spital.specializimi"
    _description = "Specializimet"

    specializim = fields.Many2one('spital.doktori', string="Specializimi")
    data = fields.Date(string="Data", required=True)
    mjek_id = fields.Many2one('spital.doktori', string="Mjeku")


# Krijimi i tabeles Departamenti

class Departamenti (models.Model):
    _name = "spital.departamenti"
    _description = "Departamenti"
    _order = "name"

    name = fields.Char(string="Departamenti", required=True)
    krye_mjek = fields.Char(string="Krye Mjeku")
#
# Krijimi i tabeles Vizita

class Konsulta (models.Model):
    _name = "spital.konsulta"
    _description = "Konsulta"

    pacient_id = fields.Many2one('spital.pacienti', string="Pacienti")
    mjek_id = fields.Many2one('spital.doktori', string="Doktori")
    dep_id = fields.Many2one('spital.departamenti', string="Departamenti")
    data = fields.Date(string="Data")
    date_fillimi = fields.Datetime(string="Data dhe Ora e fillimit", default=lambda self: fields.datetime.now())
    date_perfundimi = fields.Datetime(string="Data dhe Ora e perfundimit")
    konsulte = fields.Boolean(string="Konsulta")
    status = fields.Char(string="Statusi")
    arsyeja = fields.Text(string="Arsyeja")
    shenim = fields.Text(string="Shenim")
    statusi_kons = fields.Selection([
        ('planifikuar', 'Planifikuar'),
        ('konsulte', 'Konsulte'),
        ('perfunduar', 'Perfunduar')
    ], string="Statusi i Konsultes", default="planifikuar", required=True)
    konsulte = fields.Boolean(default=True)

   # I jep vlere automatikisht dates se perfundimit te konsultes, duke i shtuar 30 min dates se fillimit.
    @api.onchange('date_fillimi')
    def _onchange_time(self):
        DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
        self.date_perfundimi = datetime.strptime(self.date_fillimi, DATETIME_FORMAT) + timedelta(minutes=30)

    # Ndryshon statusin e doktorit pasi ndrsyhon statusi i konsultes
    @api.onchange('statusi_kons')
    def onchange_statusi(self):
        for record in self:
            if record.statusi_kons:
                if record.statusi_kons == 'konsulte':
                    record.mjek_id.write({'statusi_dok':'zene'})
                elif record.statusi_kons == 'perfunduar':
                    record.mjek_id.write({'statusi_dok':'disponueshem'})

# # Krijimi i tabeles Diagnoza
#
# class Diagnoza (models.Model):
#     _name = "spital.diagnoza"
#     _description = "Diagnoza"
#
#     id = fields.Integer(string="ID", required=True)
#     diagnoza = fields.Char(string="Diagnoza", required=True)
#
# # Krijimi i tabeles Fatura
#
# class Fatura (models.Model):
#     _name = "spital.fatura"
#     _description = "Fatura"
#
#     id = fields.Integer(string="Fatura", required=True)
#     totali = fields.Float(string="Totali", required=True)






